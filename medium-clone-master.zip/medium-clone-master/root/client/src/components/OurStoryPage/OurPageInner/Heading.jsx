import { Wrapper5 } from "../../../styled-components/components";

export const Heading = () => {
  return (
    <Wrapper5>
      <div className="fontTest">
        <h1>
          {" "}
          Every idea needs a <span className="spanClass"> Medium. </span>{" "}
        </h1>
      </div>
    </Wrapper5>
  );
};
